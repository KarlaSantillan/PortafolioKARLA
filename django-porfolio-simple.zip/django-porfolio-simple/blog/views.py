from django.shortcuts import get_object_or_404, render
from .models import Post
from django.contrib.auth.decorators import login_required

@login_required
def render_posts(request):
    posts = Post.objects.all()
    return render(request, 'posts.html', {'posts': posts})

@login_required
def post_detail(request, post_id):
    post = get_object_or_404(Post, pk=post_id)
    return render(request, 'post_detail.html', {'post': post})
