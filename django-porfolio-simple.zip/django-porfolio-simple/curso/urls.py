from django.urls import path
from .views import render_cursos,curso_detail

app_name = 'curso'

urlpatterns = [
    path('', render_cursos, name='cursos'),
    path('<int:curso_id>', curso_detail, name='curso_detail'),
]