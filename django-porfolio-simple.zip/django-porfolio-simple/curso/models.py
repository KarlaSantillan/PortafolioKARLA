from django.db import models
import datetime

class Curso(models.Model):
    institute = models.CharField(max_length=100)
    description = models.TextField()
    date = models.DateField(datetime.date.today)
    hours = models.IntegerField()
