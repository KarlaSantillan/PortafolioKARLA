from django.shortcuts import get_object_or_404, render
from .models import Curso
from django.contrib.auth.decorators import login_required

@login_required
def render_cursos(request):
    cursos = Curso.objects.all()
    return render(request, 'cursos.html', {'cursos': cursos})

@login_required
def curso_detail(request, curso_id):
    curso = get_object_or_404(Curso, pk=curso_id)
    return render(request, 'curso_detail.html', {'curso': curso})